buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath("com.android.tools.build:gradle:8.0.0")
    }
}

allprojects {
    repositories {
        google()
        mavenCentral() // Make sure this line is present
    }
}
