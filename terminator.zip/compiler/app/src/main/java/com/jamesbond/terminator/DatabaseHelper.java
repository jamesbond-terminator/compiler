package com.jamesbond.terminator;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "users.db";
    private static final String TABLE_NAME = "users";
    private static final String COL_EMAIL = "email";
    private static final String COL_PASSWORD = "password";
    private static final String COL_USERNAME = "username";
    private static final String COL_REGISTRATION_NUMBER = "registration_number";
    private static final String COL_COLLEGE = "college";
    private static final String COL_PROFILE_PHOTO = "profile_photo";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 2); // Increment version number if changes are made
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_EMAIL + " TEXT PRIMARY KEY, " +
                COL_PASSWORD + " TEXT, " +
                COL_USERNAME + " TEXT, " +
                COL_REGISTRATION_NUMBER + " TEXT, " +
                COL_COLLEGE + " TEXT, " +
                COL_PROFILE_PHOTO + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean addUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_EMAIL, email);
        contentValues.put(COL_PASSWORD, hashPassword(password)); // Hash the password
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1; // Returns true if the user is added successfully
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COL_EMAIL + "=?", new String[]{email});

        if (cursor.moveToFirst()) {
            String hashedPassword = cursor.getString(cursor.getColumnIndex(COL_PASSWORD));
            cursor.close();
            return hashedPassword.equals(hashPassword(password)); // Check hashed password
        }

        cursor.close();
        return false; // User does not exist
    }

    public boolean saveProfile(String email, String username, String registrationNumber, String college, String profilePhoto) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_REGISTRATION_NUMBER, registrationNumber);
        contentValues.put(COL_COLLEGE, college);
        contentValues.put(COL_PROFILE_PHOTO, profilePhoto);

        // Update existing user profile
        int result = db.update(TABLE_NAME, contentValues, COL_EMAIL + "=?", new String[]{email});
        return result > 0; // Returns true if the profile is updated successfully
    }

    public User getUserProfile(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COL_EMAIL + "=?", new String[]{email});

        if (cursor != null && cursor.moveToFirst()) {
            String userEmail = cursor.getString(cursor.getColumnIndex(COL_EMAIL));
            String username = cursor.getString(cursor.getColumnIndex(COL_USERNAME));
            String registrationNumber = cursor.getString(cursor.getColumnIndex(COL_REGISTRATION_NUMBER));
            String college = cursor.getString(cursor.getColumnIndex(COL_COLLEGE));
            String profilePhoto = cursor.getString(cursor.getColumnIndex(COL_PROFILE_PHOTO));

            cursor.close();
            return new User(userEmail, username, registrationNumber, college, profilePhoto); // Create user object
        }

        if (cursor != null) {
            cursor.close();
        }
        return null; // Return null if no user found
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}
