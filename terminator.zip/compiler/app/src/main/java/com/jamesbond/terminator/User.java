package com.jamesbond.terminator;

public class User {
    private String email;
    private String username;
    private String registrationNumber;
    private String college;
    private String profilePhoto; // New field for profile photo

    public User(String email, String username, String registrationNumber, String college, String profilePhoto) {
        this.email = email;
        this.username = username;
        this.registrationNumber = registrationNumber;
        this.college = college;
        this.profilePhoto = profilePhoto; // Initialize photo field
    }

    public String getEmail() {
        return email;
    }

    public String getUsername() {
        return username;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public String getCollege() {
        return college;
    }

    public String getProfilePhoto() {
        return profilePhoto; // Getter for photo URI
    }
}
