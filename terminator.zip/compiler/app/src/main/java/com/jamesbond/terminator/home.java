package com.jamesbond.terminator;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class home extends Fragment {

    private static final String ARG_EMAIL = "email";
    private static final String PREFS_NAME = "user_prefs";
    private ImageView imageViewProfilePhoto;
    private String email;

    public home() {
        // Required empty public constructor
    }

    public static home newInstance(String email) {
        home fragment = new home();
        Bundle args = new Bundle();
        args.putString(ARG_EMAIL, email);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        imageViewProfilePhoto = view.findViewById(R.id.imageViewProfilePhoto);
        LinearLayout book = view.findViewById(R.id.book);
        LinearLayout result = view.findViewById(R.id.result);
        LinearLayout time = view.findViewById(R.id.time);
        ImageView op = view.findViewById(R.id.chat);
        LinearLayout paper = view.findViewById(R.id.paper);
        LinearLayout course = view.findViewById(R.id.course);


        book.setOnClickListener(v -> {
            Fragment bookFragment = new book();
            ((MainActivity) getActivity()).loadFragment(bookFragment);
        });

        result.setOnClickListener(v -> {
            String url = "https://coe1.annauniv.edu/home/";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });

        time.setOnClickListener(v -> {
            Fragment timeFragment = new tt();
            ((MainActivity) getActivity()).loadFragment(timeFragment);
        });

        op.setOnClickListener(v -> {
            Fragment opFragment = new chat();
            ((MainActivity) getActivity()).loadFragment(opFragment);
        });

        paper.setOnClickListener(v -> {
            Fragment paperFragment = new paper();
            ((MainActivity) getActivity()).loadFragment(paperFragment);
        });

        course.setOnClickListener(v -> {
            Fragment courseFragment = new course();
            ((MainActivity) getActivity()).loadFragment(courseFragment);
        });



        if (getArguments() != null) {
            email = getArguments().getString(ARG_EMAIL);
        }

        // Example of loading a profile picture (this is just a placeholder)
        loadProfilePicture(email);

        /* LinearLayout chat = view.findViewById(R.id.chat);
        chat.setOnClickListener(v -> {
            ((MainActivity) getActivity()).requestStoragePermission(); // Request permission to pick an image
        });*/

        return view;
    }

    private void loadProfilePicture(String email) {
        // Logic to load profile picture
    }

    private boolean isUserLoggedIn() {
        SharedPreferences prefs = getActivity().getSharedPreferences(PREFS_NAME, getActivity().MODE_PRIVATE);
        return prefs.getBoolean("is_logged_in", false);
    }

    @Override
    public void onResume() {
        super.onResume();
        updateNotificationIcon();
    }

    private void updateNotificationIcon() {
        int count = NotificationManager.getInstance().getUnreadCount();
        if (count > 0) {
            imageViewProfilePhoto.setImageResource(R.drawable.bell_with_notification); // Change to a different icon
            // Optionally, show a badge or a number indicating unread count
        } else {
            imageViewProfilePhoto.setImageResource(R.drawable.bell); // Default icon
        }
    }

}
