package com.jamesbond.terminator;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;

public class account extends Fragment {

    private EditText editTextEmail;
    private EditText editTextPassword;
    private Button buttonLogin;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account, container, false);

        editTextEmail = view.findViewById(R.id.username);
        editTextPassword = view.findViewById(R.id.password);
        buttonLogin = view.findViewById(R.id.loginButton);
        TextView textViewSignup = view.findViewById(R.id.signup);

        // Sign up navigation
        textViewSignup.setOnClickListener(v -> {
            Log.d("AccountFragment", "Navigating to SignupFragment");
            Fragment signupFragment = new signin();
            ((MainActivity) getActivity()).loadFragment(signupFragment);
        });

        // Login button listener
        buttonLogin.setOnClickListener(v -> login());

        return view;
    }

    private void login() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(getActivity(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
        if (dbHelper.checkUser(email, password)) {
            ((MainActivity) getActivity()).saveUserEmail(email);
            home homeFragment = home.newInstance(email);
            ((MainActivity) getActivity()).loadFragment(homeFragment);
        } else {
            Toast.makeText(getActivity(), "Invalid email or password. Please sign up.", Toast.LENGTH_SHORT).show();
        }
    }
}
