package com.jamesbond.terminator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.FragmentManager;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class profile extends Fragment {
    private static final int PICK_IMAGE_REQUEST = 1;
    private EditText editTextUsername;
    private EditText editTextRegistrationNumber;
    private Spinner spinnerCollege;
    private ImageView imageViewProfilePhoto;
    private Button buttonSelectProfilePhoto;
    private Button buttonFinish;
    private Uri profilePhotoUri;
    private String email;

    public profile() {
        // Required empty public constructor
    }

    public static profile newInstance(String email) {
        profile fragment = new profile();
        Bundle args = new Bundle();
        args.putString("email", email);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        editTextUsername = view.findViewById(R.id.profileUsername);
        editTextRegistrationNumber = view.findViewById(R.id.registrationNumber);
        spinnerCollege = view.findViewById(R.id.collegeSpinner);
        imageViewProfilePhoto = view.findViewById(R.id.imageViewProfilePhoto);
        buttonSelectProfilePhoto = view.findViewById(R.id.buttonSelectProfilePhoto);
        buttonFinish = view.findViewById(R.id.finishButton);

        if (getArguments() != null) {
            email = getArguments().getString("email");
        }

        String[] colleges = {"Select College", "Arunai Engineering College", "SKP Engineering College", "Anna university, SSN Engineering College", ""};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, colleges);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCollege.setAdapter(adapter);

        buttonSelectProfilePhoto.setOnClickListener(v -> openFileChooser());
        buttonFinish.setOnClickListener(v -> createProfile());

        return view;
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Profile Photo"), PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == getActivity().RESULT_OK && data != null && data.getData() != null) {
            profilePhotoUri = data.getData();
            imageViewProfilePhoto.setImageURI(profilePhotoUri);
        }
    }

    private void createProfile() {
        String username = editTextUsername.getText().toString().trim();
        String registrationNumber = editTextRegistrationNumber.getText().toString().trim();
        String college = (spinnerCollege.getSelectedItem() != null) ? spinnerCollege.getSelectedItem().toString() : null;

        Log.d("ProfileFragment", "Creating profile with: " + username + ", " + registrationNumber + ", " + college);

        if (username.isEmpty() || registrationNumber.isEmpty() || profilePhotoUri == null || "Select College".equals(college)) {
            Toast.makeText(getActivity(), "Please fill in all fields and select a photo", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
        try {
            boolean isProfileSaved = dbHelper.saveProfile(email, username, registrationNumber, college, profilePhotoUri.toString());

            if (isProfileSaved) {
                Toast.makeText(getActivity(), "Profile created successfully", Toast.LENGTH_SHORT).show();

                // Redirect to HomeFragment
                home homeFragment = home.newInstance(email); // Pass the email to home fragment
                ((MainActivity) getActivity()).loadFragment(homeFragment);
            } else {
                Toast.makeText(getActivity(), "Profile creation failed", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("ProfileFragment", "Error creating profile", e);
            Toast.makeText(getActivity(), "An error occurred: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }





}
