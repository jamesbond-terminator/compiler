package com.jamesbond.terminator;

import android.net.Uri; // Import Uri class
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class inprofile extends Fragment {
    private TextView textViewEmail;
    private TextView textViewUsername;
    private TextView textViewRegistrationNumber;
    private TextView textViewCollege;
    private ImageView imageViewProfilePhoto;

    // Default constructor
    public inprofile() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_inprofile, container, false);

        // Initialize views
        textViewEmail = view.findViewById(R.id.textViewEmail);
        textViewUsername = view.findViewById(R.id.profileUsername);
        textViewRegistrationNumber = view.findViewById(R.id.registrationNumber);
        textViewCollege = view.findViewById(R.id.textViewCollege);
        imageViewProfilePhoto = view.findViewById(R.id.imageViewProfilePhoto);

        // Retrieve email from arguments
        if (getArguments() != null) {
            String email = getArguments().getString("email");
            loadUserProfile(email);
        }

        return view;
    }

    private void loadUserProfile(String email) {
        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
        User user = dbHelper.getUserProfile(email);

        if (user != null) {
            textViewEmail.setText(user.getEmail());
            textViewUsername.setText(user.getUsername());
            textViewRegistrationNumber.setText(user.getRegistrationNumber());
            textViewCollege.setText(user.getCollege());

            // Load profile photo
            String profilePhotoUriString = user.getProfilePhoto();
            if (profilePhotoUriString != null) {
                imageViewProfilePhoto.setImageURI(Uri.parse(profilePhotoUriString));
            }
        }
    }

    // Method to create a new instance of inprofile with the email
    public static inprofile newInstance(String email) {
        inprofile fragment = new inprofile();
        Bundle args = new Bundle();
        args.putString("email", email);
        fragment.setArguments(args);
        return fragment;
    }
}
