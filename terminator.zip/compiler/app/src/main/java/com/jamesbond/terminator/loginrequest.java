package com.jamesbond.terminator;


public class loginrequest {
    private String email;
    private String password;

    public loginrequest(String email, String password) {
        this.email = email;
        this.password = password;
    }
}

