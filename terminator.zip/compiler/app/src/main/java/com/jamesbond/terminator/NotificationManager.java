package com.jamesbond.terminator;

public class NotificationManager {
    private static NotificationManager instance;
    private int unreadCount = 0;

    private NotificationManager() {}

    public static NotificationManager getInstance() {
        if (instance == null) {
            instance = new NotificationManager();
        }
        return instance;
    }

    public void notifyNewReply(ChatPost post) {
        unreadCount++;
        // Notify the UI to update the bell icon
    }

    public int getUnreadCount() {
        return unreadCount;
    }

    public void resetUnreadCount() {
        unreadCount = 0;
    }
}
