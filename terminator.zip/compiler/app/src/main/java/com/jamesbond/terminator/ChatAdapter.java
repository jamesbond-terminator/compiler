package com.jamesbond.terminator;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {

    private ArrayList<ChatPost> chatPosts;
    private Context context;

    public ChatAdapter(ArrayList<ChatPost> chatPosts, Context context) {
        this.chatPosts = chatPosts;
        this.context = context;
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat_post, parent, false);
        return new ChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        ChatPost post = chatPosts.get(position);
        holder.userNameTextView.setText(post.getUserName());
        holder.messageTextView.setText(post.getMessage());

        // Display replies
        StringBuilder repliesText = new StringBuilder();
        for (String reply : post.getReplies()) {
            repliesText.append(reply).append("\n");
        }
        holder.repliesTextView.setText(repliesText.toString().trim());

        holder.replyButton.setOnClickListener(v -> {
            showReplyDialog(post);
        });
    }

    private void showReplyDialog(ChatPost post) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Reply to " + post.getUserName());

        final EditText input = new EditText(context);
        builder.setView(input);

        builder.setPositiveButton("OK", (dialog, which) -> {
            String reply = input.getText().toString();
            if (!reply.isEmpty()) {
                post.addReply(reply);
                notifyDataSetChanged(); // Update the adapter
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    @Override
    public int getItemCount() {
        return chatPosts.size();
    }

    static class ChatViewHolder extends RecyclerView.ViewHolder {
        private TextView userNameTextView;
        private TextView messageTextView;
        private TextView repliesTextView;
        private Button replyButton;

        public ChatViewHolder(@NonNull View itemView) {
            super(itemView);
            userNameTextView = itemView.findViewById(R.id.userNameTextView);
            messageTextView = itemView.findViewById(R.id.messageTextView);
            repliesTextView = itemView.findViewById(R.id.repliesTextView);
            replyButton = itemView.findViewById(R.id.replyButton);
        }
    }
}
