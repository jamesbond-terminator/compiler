package com.jamesbond.terminator;


public class loginresponse {
    private String message;

    public String getMessage() {
        return message;
    }
}