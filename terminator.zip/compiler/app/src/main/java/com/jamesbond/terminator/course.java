package com.jamesbond.terminator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.VideoView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class course extends Fragment {

    private VideoView videoView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_course, container, false);
        // c1
        FrameLayout c1 = view.findViewById(R.id.c1);
        c1.setOnClickListener(v -> {
            String url = "https://youtu.be/DuSbZoh_7TI?si=NNcnIMr-zFaoainH";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        });


    // c2
        FrameLayout c2 = view.findViewById(R.id.c2);
        c2.setOnClickListener(v -> {
            String url = "https://youtu.be/vg_2FkWgL04?si=wfZvOCYd8ZAJM6Ud";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        });


        // c3
        FrameLayout c3 = view.findViewById(R.id.c3);
        c3.setOnClickListener(v -> {
            String url= "https://youtu.be/PKFvMIa37tY?si=OwzHOsfTBPEs6scm";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        });

        //c4

        FrameLayout c4 = view.findViewById(R.id.c4);
        c4.setOnClickListener(v -> {
            String url = "https://youtu.be/b2opIFiOpGw?si=jT1NRUYDW9cHdrYJ";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        });

        //c5

        FrameLayout c5 = view.findViewById(R.id.c5);
        c4.setOnClickListener(v -> {
            String url = "https://youtu.be/xDCj8RM5OTg?si=f05FaVyAkcXxuvPH";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        });

        //c6

        FrameLayout c6 = view.findViewById(R.id.c6);
        c4.setOnClickListener(v -> {
            String url = "https://youtu.be/NslZK-3RJXo?si=euNLksWql8MVvmtD";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(urlrl));
            startActivity(intent);
        });

        //c7

        FrameLayout c7 = view.findViewById(R.id.c7);
        c4.setOnClickListener(v -> {
            String url = "https://youtu.be/98wHiXX_jmk?si=JW8tGQCh0veYQnYy";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        });

        //c8

        FrameLayout c8 = view.findViewById(R.id.c8);
        c4.setOnClickListener(v -> {
            String url = "https://youtu.be/PlM82pVD6xE?si=EYjxOunu_fkM9pWN";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(Url));
            startActivity(intent);
        });

        //c9

        FrameLayout c9 = view.findViewById(R.id.c9);
        c4.setOnClickListener(v -> {
            String url = "https://youtu.be/XGAQgVKw1GI?si=rE3N1nxlC5EcjQbQ";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(Url));
            startActivity(intent);
        });

        // c10

        FrameLayout c10 = view.findViewById(R.id.c10);
        c10.setOnClickListener(v -> {
            String url = "https://youtu.be/6x63PnU4Llg?si=O0jL9NWUN-esro2_";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        });


        return view;
    }


    @Override
    public void onPause() {
        super.onPause();
        if (videoView.isPlaying()) {
            videoView.pause();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        videoView.start();
    }
}
