package com.jamesbond.terminator;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BookFragment extends Fragment {

    private List<Book> bookList;
    private ArrayAdapter<Book> bookAdapter;
    private ListView listView;
    private SearchView searchView;

    public static class Book implements Serializable {
        private String name;
        private List<String> pages; // List of pages

        public Book(String name, List<String> pages) {
            this.name = name;
            this.pages = pages;
        }

        public String getName() {
            return name;
        }

        public List<String> getPages() {
            return pages;
        }

        @Override
        public String toString() {
            return name; // Used by ArrayAdapter
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_book, container, false);

        listView = view.findViewById(R.id.listView);
        searchView = view.findViewById(R.id.searchView);

        // Initialize the book list
        bookList = getBooks();
        bookAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, bookList);
        listView.setAdapter(bookAdapter);

        // Set up the SearchView
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterBooks(newText);
                return true;
            }
        });

        // Handle book selection
        listView.setOnItemClickListener((adapterView, view1, position, id) -> {
            Book selectedBook = bookAdapter.getItem(position);
            if (selectedBook != null) {
                openBookPages(selectedBook);
            }
        });

        return view;
    }

    private void filterBooks(String query) {
        List<Book> filteredList = new ArrayList<>();
        for (Book book : bookList) {
            if (book.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(book);
            }
        }
        bookAdapter.clear();
        bookAdapter.addAll(filteredList);
        bookAdapter.notifyDataSetChanged();
    }

    private void openBookPages(Book book) {
        BookPagesFragment bookPagesFragment = BookPagesFragment.newInstance(book);
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.nav_host_fragment, bookPagesFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    private List<Book> getBooks() {
        List<Book> books = new ArrayList<>();
        books.add(new Book("Harry Potter", Arrays.asList("Page 1", "Page 2", "Page 3")));
        books.add(new Book("The Hobbit", Arrays.asList("Page 1", "Page 2", "Page 3")));
        books.add(new Book("1984", Arrays.asList("Page 1", "Page 2", "Page 3")));
        return books;
    }
}
