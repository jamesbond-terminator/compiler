package com.jamesbond.terminator;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class signin extends Fragment {
    private EditText editTextUsername;
    private EditText editTextPassword;
    private EditText editTextReEnterPassword;
    private Button buttonSignup;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_signin, container, false);

        editTextUsername = view.findViewById(R.id.username);
        editTextPassword = view.findViewById(R.id.password);
        editTextReEnterPassword = view.findViewById(R.id.reEnterPassword);
        buttonSignup = view.findViewById(R.id.signup);
        TextView textView = view.findViewById(R.id.login);

        // Navigate to login
        textView.setOnClickListener(v -> {
            Fragment accountFragment = new account();
            ((MainActivity) getActivity()).loadFragment(accountFragment);
        });

        // Signup button listener
        buttonSignup.setOnClickListener(v -> signup());

        return view;
    }

    private void signup() {
        String email = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String reEnterPassword = editTextReEnterPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty() || reEnterPassword.isEmpty()) {
            Toast.makeText(getActivity(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(reEnterPassword)) {
            Toast.makeText(getActivity(), "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
        if (dbHelper.addUser(email, password)) {
            Toast.makeText(getActivity(), "User registered successfully", Toast.LENGTH_SHORT).show();

            // Save user email and logged-in status
            ((MainActivity) getActivity()).saveUserEmail(email);

            // Navigate to home page
            profile profileFragment = profile.newInstance(email); // Pass the email to home fragment
            ((MainActivity) getActivity()).loadFragment(profileFragment);
        } else {
            Toast.makeText(getActivity(), "User registration failed", Toast.LENGTH_SHORT).show();
        }
    }
}
