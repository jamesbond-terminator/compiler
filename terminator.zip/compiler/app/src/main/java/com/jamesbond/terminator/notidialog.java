package com.jamesbond.terminator;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class notidialog extends dialognoti {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate your dialog layout (replace 'dialog_layout' with your actual layout resource)
        return inflater.inflate(R.layout.fragment_dialognoti, container, false);
    }
}
