package com.jamesbond.terminator;

import java.util.ArrayList;

public class ChatPost {
    private String userName;
    private String message;
    private ArrayList<String> replies;

    public ChatPost(String userName, String message) {
        this.userName = userName;
        this.message = message;
        this.replies = new ArrayList<>();
    }

    public String getUserName() {
        return userName;
    }

    public String getMessage() {
        return message;
    }

    public ArrayList<String> getReplies() {
        return replies;
    }

    public void addReply(String reply) {
        replies.add(reply);
    }
}
