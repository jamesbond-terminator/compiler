pluginManagement {
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "terminator" // Replace with your project name
include(":app") // Include your app module

